var modifyFlag = false;
var createFlag = false;
$(document).ready(function(e) {
	console.log('document ready func');
	
	$( "#validFromDt" ).datepicker({
		  dateFormat: "mm/dd/yy",
		  changeMonth: true,
		  changeYear: true,
		  yearRange: "-118:+482"
		});
	
	$( "#validToDt" ).datepicker({
		  dateFormat: "mm/dd/yy",
		  changeMonth: true,
		  changeYear: true,
		  yearRange: "-118:+482"
		});
	
	$( "#modValidFromDt" ).datepicker({
		  dateFormat: "mm/dd/yy",
		  changeMonth: true,
		  changeYear: true,
		  yearRange: "-118:+482"
		});
	
	$( "#modValidToDt" ).datepicker({
		  dateFormat: "mm/dd/yy",
		  changeMonth: true,
		  changeYear: true,
		  yearRange: "-118:+482"
		});
	
	$( "#effectiveDateId" ).datepicker({
		  dateFormat: "mm/dd/yy",
		  changeMonth: true,
		  changeYear: true,
		  yearRange: "-118:+482"
		});
	
	$.ajaxSetup({cache : false});
	$.ajax({
		type : 'GET',
		url : 'PopulateColalteralCodes.jsp',
		data : {
			action : "collateralCode"
		},
		cache : false,
		async : false,
		success : function(data) {
			populateCollCdData(data);
		},
	});
	$.ajaxSetup({cache : false});
	$.ajax({
		type : 'GET',
		url : 'PopulateTripartyAgntFiles.jsp',
		data : {
			action : "tripartyAgntId"
		},
		cache : false,
		async : false,
		success : function(data) {
			populateTPAFData(data);
		},
	});
	$.ajaxSetup({cache : false});
	$.ajax({
		type : 'GET',
		url : 'PopulateHouseId.jsp',
		data : {
			action : "houseId"
		},
		cache : false,
		async : false,
		success : function(data) {
			populateHouseIdData(data);
		},
	});
	$.ajaxSetup({cache : false});
	$.ajax({
		type : 'GET',
		url : 'PopulateDMLCTPYId.jsp',
		data : {
			action : "dmlCtpyId"
		},
		cache : false,
		async : false,
		success : function(data) {
			populateDMLCtpyIdData(data);
		},
	});
	
	$('#clearBtn').click(function() {
		createFlag = false;
		modifyFlag = false;		
		console.log('clear func');
		var date = new Date();
		var year = date.getFullYear();
		var month = date.getMonth()+1;
		var date = date.getDate();
		$.ajaxSetup({cache : false});
		$.ajax({
			type : 'GET',
			url : 'DMLCollateralAcctXRefAux.jsp',
			data : {
				action : "clear"
			},
			cache : false,
			async : false,
			success : function(data) {
				console.log("done");
				$('#collCdId').val("");
				$('#tripartyAgntId').val("");
				$('#validFromDt').val("");
				$('#validToDt').val("");
				$('#houseId').val("");
				$('#collAcctId').val("");
				$('#ctpyId').val("");
				$('#activeId').val("");
				$.ajaxSetup({cache : false});
				$.ajax({
					type : 'GET',
					url : 'DMLCollateralAcctXRefAux.jsp',
					data : {},
					cache : false,
					success : function(data) {
						successCallBack(data);
						$('#validToDt').val('01/31/2500');
						$('#validFromDt').val(month+"/"+date+"/"+year);
					},
				});
			}
		});
		
	});
	
	$('#collateralTypeTable').remove();
	$.ajaxSetup({cache : false});
	$.ajax({
		type : 'GET',
		url : 'DMLCollateralAcctXRefAux.jsp',
		data : {},
		async : false,
		cache : false,
		success : function(data) {
			successCallBack(data);
		},
	});
	
	$('#modifyBtn').click(function() {		
		var tpafId = $('#modTripartyAgntId').val();
		$.ajax({
			type : 'GET',
			url : 'ModifyCollAccountDetails.jsp',
			data : {				
				"tpafId" : tpafId,
				"action" : 'ModifyDMLCollAccount' 
			},
			async : false, 
			cache : false,
			success : function(data) {
				populateModifyCollAccountData(data);
			},
		});		
		$(this).prop('disabled', true);
		$('#createBtn').prop('disabled', true);	
		modifyFlag = true;
		if($('#curRecFlg').html() !="" && $('#curRecFlg').html()!=null){
			if($('#curRecFlg').html() == "N"){
			alert('You can only modify the most recent Valid From record.');
			return false;
		 }
		}
		$('.modifyClass').each(function(){
			$(this).prop( "disabled", false);
		});
		var modHouseId = '', modActiveId = '', modCollCdId = '', modCollAcctId = '', modTripartyAgntId = '', modCtpyId = '';
		var columnHeaders = [];
		$('#collateralTypeTable tr:first th').each(function(index) {
				columnHeaders.push($(this).text());
		});
		console.log(columnHeaders);
		$('input[name = "dmlCollAcctXRefs"]:checked').closest('tr').find('td').each(function(index) {
			if(columnHeaders[index]=="")
				modCollCdId = $(this).find('input').val();
			else if(columnHeaders[index]=='HOUSEACCTID')
				modHouseId = $(this).text();
			else if(columnHeaders[index]=='ACTIVEFLG')
				modActiveId = $(this).text();
			else if(columnHeaders[index]=='COLLATERALACCT')
				modCollAcctId = $(this).text();
			else if(columnHeaders[index]=='TRIPARTYAGNTID')
				modTripartyAgntId = $(this).text();
			else if(columnHeaders[index]=='CTPYID')
				modCtpyId = $(this).text();
		});
		console.log(modCollCdId);
		console.log(modHouseId);
		console.log(modActiveId);
		console.log(modCollAcctId);
		console.log(modTripartyAgntId);
		console.log(modCtpyId);
		$.ajaxSetup({cache : false});
		$.ajax({
			type : 'GET',
			url : 'DMLCollateralAcctCrossRefDetail.jsp',
			data : {
				"modHouseId" : modHouseId,
				"modActiveId" : modActiveId,
				"modCollCdId" : modCollCdId,
				"modCollAcctId" : modCollAcctId,
				"modTripartyAgntId" : modTripartyAgntId,
				"modCtpyId" : modCtpyId,
				"action" : 'getDMLCollateralAcctXRefDetails' 
			},
			async : false,
			cache : false,
			success : function(data) {
				enrichModifyGrid(data);
			},
		});
	}); 
	
	$('#cancelBtn').click(function() {
		if(createFlag == true || modifyFlag == true){		
		var modifyModeDialogVar = $('#modifyModeDialog');
		modifyModeDialogVar.dialog({
			modal: true,
		    draggable: false,
		    resizable: false,
		    position: ['center', 'top'],
		    show: 'blind',
		    hide: 'blind',
		    width: 500,
		    height: 350,
			buttons : {
				'OK' : function() {
					createFlag = false;
					modifyFlag = false;
					 $.ajax({
						type : 'GET',
						url : 'DMLCollateralAcctXRefAux.jsp',
						data : {},
						async : false,
						cache : false,
						success : function(data) {
						successCallBack(data);
						},
					});					
					 $('#modHouseId').prop('disabled', true);					 
					 $('#modCollCdId').prop('disabled', true);					 					 
					 $('#modCtpyId').prop('disabled', true);					 
					 $('#modActiveId').prop('disabled', true);
					 $('#modCollAcctId').val("");
					 $('#saveBtn').prop('disabled', true);
					 $('#cancelBtn').prop('disabled', true);
					 $('#createBtn').prop('disabled', false);
					 $('#modifyBtn').prop('disabled', false);
					 $('.modifyClass.saveClass').prop('disabled', true);
					 $(this).dialog('close');
				},				
				'Cancel' : function(){					
					 $(this).dialog('close');
				}
			}
			
		});
		modifyModeDialogVar.dialog('open');	
		}		
	    modifyFlag = false;
	    createFlag = false;
		$('#createBtn').prop('disabled', false);
		$('#modifyBtn').prop('disabled', false);
		$.ajaxSetup({cache : false});
		$.ajax({
			type : 'GET',
			url : 'DMLCollateralAcctCrossRefDetail.jsp',
			data : {
				"action" : 'cancel' 
			},
			async : false,
			cache : false,
			success : function(data) {
				$('#modHouseId').val("");
				$('#modCollCdId').val("");
				$('#modTripartyAgntId').val("");
				$('#modValidFromDt').val("");
				$('#modCollAcctId').val("");
				$('#modValidToDt').val("");
				$('#modCtpyId').val("");
				$('#modActiveId').val("");
				$('#saveBtn').prop('disabled', true);
				$('#cancelBtn').prop('disabled', true);
				$('#modLastModSignOnId').text("");
				$('#modLastModDateTime').text("");
				$('#createBtn').prop('disabled', false);
				$('#modifyBtn').prop('disabled', false);
				$('.modifyClass.saveClass').prop('disabled', true);
				
			},
		});
		
	});
	
	$('#createBtn').click(function() {
		createFlag = true;
		$(this).prop('disabled', true);
		$('#modifyBtn').prop('disabled', true);	
		$("#modActiveId").val("Y");		
		$('#modHouseId').val("");
		$('#modCollCdId').val("");
		$('#modTripartyAgntId').val("");
		var date = new Date();
		todayDate = ((date.getMonth()+1) + '/' + (date.getDate()) + '/' + date.getFullYear());		
		$('#modValidFromDt').val(todayDate);
		$('#modValidToDt').val("01/31/2500")				
		$('#modCollAcctId').val("");		
		$('#modCtpyId').val("");		
		$('#modLastModSignOnId').text("");
		$('#modLastModDateTime').text("");	   
		$('input[name = "dmlCollAcctXRefs"]:checked').prop("checked",false);
		$('.saveClass').each(function(){
			$(this).prop( "disabled", false);
		});		
		$.ajaxSetup({cache : false});
		$.ajax({
			type : 'GET',
			url : 'DMLCollateralAcctCrossRefDetail.jsp',
			data : {
				"action" : 'create' 
			},
			async : false,
			cache : false,
			success : function(data) {
				$('#saveBtn').prop('disabled', false);
				$('#cancelBtn').prop('disabled', false);
			},
		});
		
			
	});
	
	$('#saveBtn').click(function() {
		var mandatoryFields = '';
		var date = new Date();
		$('#effectiveDateId').val((date.getMonth()+1) +'/'+ date.getDate() +'/'+ date.getFullYear());
		var clientValidateFlag = true;
		if($('#modCollCdId').val()=="" || $('#modCollCdId').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'Collateral Code <br/>';
			$('#modCollCdId').css('border','2px solid red');
		}else {
			$('#modCollCdId').css('border','');
		}
		if($('#modTripartyAgntId').val()=="" || $('#modTripartyAgntId').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'Triparty Agent File <br/>';
			$('#modTripartyAgntId').css('border','2px solid red');
		}else {
			$('#modTripartyAgntId').css('border','');
		}
		if($('#modValidFromDt').val()=="" || $('#modValidFromDt').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'Valid From <br/>';
			$('#modValidFromDt').css('border','2px solid red');
		}else {
				$('#modValidFromDt').css('border','');
		}
		if($('#modHouseId').val()=="" || $('#modHouseId').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'House Id <br/>';
			$('#modHouseId').css('border','2px solid red');
		}else {
			$('#modHouseId').css('border','');
		}
		if($('#modCollAcctId').val()=="" || $('#modCollAcctId').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'Collateral Acct <br/>';
			$('#modCollAcctId').css('border','2px solid red');
		}else {
			$('#modCollAcctId').css('border','');
		}
		if($('#modValidToDt').val()=="" || $('#modValidToDt').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'Valid To <br/>';
			$('#modValidToDt').css('border','2px solid red');
		}else {
				$('#modValidToDt').css('border','');
		}
		if($('#modCtpyId').val()=="" || $('#modCtpyId').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'Primary DML Ctpy Id <br/>';
			$('#modCtpyId').css('border','2px solid red');
		}else {
			$('#modCtpyId').css('border','');
		}
		if($('#modActiveId').val()=="" || $('#modActiveId').val()==null){
			clientValidateFlag = false;
			mandatoryFields = mandatoryFields + 'Active/Inactive <br/>';
			$('#modActiveId').css('border','2px solid red');
		}else {
			$('#modActiveId').css('border','');
		}
		if(!clientValidateFlag){
			//alert('Required fields are missing: \n'+mandatoryFields.substring(0,(mandatoryFields.length-1)));			
			var dialog2 = $('#requiredFieldsDialog');	
			dialog2.dialog({
				modal: true,
			    draggable: false,
			    resizable: false,
			    position: ['center', 'top'],
			    show: 'blind',
			    hide: 'blind',
			    width: 500,
			    height: 350,
			    open: function() {			        
			        $(this).html('Required fields are missing: <br/><br/>'+mandatoryFields.substring(0,(mandatoryFields.length-1)));
			      },
				buttons : {
					'OK' : function() {
						//do activity for cancel
						dialog2.dialog('close');
					},					
					'Cancel' : function(){						
						modifyFlag = false;
						createFlag = false;
						$('#collateralTypeTable').remove();
						$.ajaxSetup({cache : false});											
						$.ajax({
								type : 'GET',
								url : 'DMLCollateralAcctXRefAux.jsp',
								data : {},
								async : false,
								cache : false,
								success : function(data) {
									successCallBack(data);
								},
							});
						 $('#modCollCdId').prop('disabled', true);
						 $('#modCollCdId').css('border','');					
						 $('#modHouseId').prop('disabled', true);
						 $('#modHouseId').css('border','');
						 $('#modCtpyId').prop('disabled', true);
						 $('#modCtpyId').css('border','');
						 $('#modTripartyAgntId').prop('disabled', true);
						 $('#modTripartyAgntId').css('border','');
						 $('#modCollAcctId').prop('disabled', true);
						 $('#modCollAcctId').css('border','');
						 $('#saveBtn').prop('disabled', true);
						 $('#cancelBtn').prop('disabled', true);
						 $('#createBtn').prop('disabled', false);
						 $('#modifyBtn').prop('disabled', false);
						 $('.modifyClass.saveClass').prop('disabled', true);
						dialog2.dialog('close');
					}
				}
				
			});
			dialog2.dialog('open');
			return false;
		}
		if(clientValidateFlag) {
			var validFrDt = $('#modValidFromDt').val();
			var splitArray = validFrDt.split("/");
			if(splitArray[0] < 0 || splitArray[0] > 12) {
				clientValidateFlag = false;
				$('#modValidFromDt').css('border','2px solid red');
				alert('Invalid Entry! Not a supported date format - Valid From');
				return false;
			}else if(splitArray[1] < 0 || splitArray[1] > 31) {
				clientValidateFlag = false;
				$('#modValidFromDt').css('border','2px solid red');
				alert('Invalid Entry! Not a supported date format - Valid From');
				return false;
			}else if(splitArray[2] < 1900 || splitArray[2] > 2500) {
				clientValidateFlag = false;
				$('#modValidFromDt').css('border','2px solid red');
				alert('Invalid Entry! Not a supported date format - Valid From');
				return false;
			}
			
			splitArray = [];
			var validToDt = $('#modValidToDt').val();
			splitArray = validToDt.split("/");
			if(splitArray[0] < 0 || splitArray[0] > 12) {
				clientValidateFlag = false;
				$('#modValidToDt').css('border','2px solid red');
				alert('Invalid Entry! Not a supported date format - Valid To');
				return false;
			}else if(splitArray[1] < 0 || splitArray[1] > 31) {
				clientValidateFlag = false;
				$('#modValidToDt').css('border','2px solid red');
				alert('Invalid Entry! Not a supported date format - Valid To');
				return false;
			}else if(splitArray[2] < 1900 || splitArray[2] > 2500) {
				clientValidateFlag = false;
				$('#modValidToDt').css('border','2px solid red');
				alert('Invalid Entry! Not a supported date format - Valid To');
				return false;
			}
			
			$.ajaxSetup({cache : false});
			$.ajax({
				type : 'GET',
				url : 'DMLCollateralAcctCrossRefDetail.jsp',
				data : {
					"action" : 'saveOrUpdate',
					"saveCollId" : $('#modCollCdId').val(),
					"saveTripartyAgntId" : $('#modTripartyAgntId').val(),
					"saveValidFromDt" : $('#modValidFromDt').val(),
					"saveHouseId" : $('#modHouseId').val(),
					"saveCollAcctId" : $('#modCollAcctId').val(),
					"saveValidToDt" : $('#modValidToDt').val(),
					"saveCtpyId" : $('#modCtpyId').val(),
					"saveActiveFlag" : $('#modActiveId').val()
				},
				async : false,
				cache : false,
				success : function(data) {
					//alert(data);					
					var index = data.lastIndexOf("}");
					var str = data.substring(1,(index));
					if(str == 'Data Saved Successfully. ') {
						alert(str);						
						modifyFlag = false;
						createFlag = false;
						$('#collateralTypeTable').remove();
						$.ajaxSetup({cache : false});
						$.ajax({
							type : 'GET',
							url : 'DMLCollateralAcctXRefAux.jsp',
							data : {},
							cache : false,
							success : function(data) {
								successCallBack(data);
							},
						});
						$('#saveBtn').prop('disabled', true);
						$('#cancelBtn').prop('disabled', true);
						$('#createBtn').prop('disabled', false);
						$('#modifyBtn').prop('disabled', false);
						$('.saveClass').prop('disabled', true);
					}else if(str == 'PF_OK'){
						//show dialog div related to processing fields case
						var dialog1 = $('#dialog-1');
						dialog1.dialog({
							modal: true,
						    draggable: false,
						    resizable: false,
						    position: ['center', 'top'],
						    show: 'blind',
						    hide: 'blind',
						    width: 500,
						    height: 250,
							buttons : {
								'Correction' : function() {
									//do activity for correction
									$.ajax({
										type : 'GET',
										url : 'DMLCollateralAcctCrossRefDetail.jsp',
										data : {
											"action" : 'correct',
											"imode" : 'U',
											"saveCollId" : $('#modCollCdId').val(),
											"saveTripartyAgntId" : $('#modTripartyAgntId').val(),
											"saveValidFromDt" : $('#modValidFromDt').val(),
											"saveHouseId" : $('#modHouseId').val(),
											"saveCollAcctId" : $('#modCollAcctId').val(),
											"saveValidToDt" : $('#modValidToDt').val(),
											"saveCtpyId" : $('#modCtpyId').val(),
											"saveActiveFlag" : $('#modActiveId').val(),
										},
										async : false,
										cache : false,
										success : function(data) {
											var index = data.lastIndexOf("}");
											var str = data.substring(1,(index));
											if(str == 'Data Saved Successfully. ') {
												alert(str);												
												$('#saveBtn').prop('disabled', true);
												$('#cancelBtn').prop('disabled', true);
												$('#createBtn').prop('disabled', false);
												$('#modifyBtn').prop('disabled', false);
												$('.modifyClass.saveClass').prop('disabled', true);
											}else {
												alert(str);
												return false;
											}
											modifyFlag = false;
											createFlag = false;
											$('#collateralTypeTable').remove();
											$.ajaxSetup({cache : false});
											$.ajax({
												type : 'GET',
												url : 'DMLCollateralAcctXRefAux.jsp',
												data : {},
												cache : false,
												success : function(data) {
													successCallBack(data);
												},
											});
										},
									});
									dialog1.dialog('close');
								},
								'Change' : function() {
									//do activity for change
									//perform validations for effective data change
									var effectiveDate = $('#effectiveDateId').val();
									var validFr = $('#modValidFromDt').val();
									var myDate = new Date(effectiveDate);
									var today = new Date();
									var validFrDate = new Date(validFr);
									if ( myDate > today ) { //future date
										alert('Effective Date cannot be greater than today');
										return false;
									}else if(myDate.setHours(0,0,0,0) == today.setHours(0,0,0,0)) { //entered date is equal to today's date
										alert('Effective Date cannot be the equal to Current Valid From date  for a change. It can only be a correction.');
										return false;
									}else if ( myDate < validFrDate ) { //entered date is less than today's date
										alert('Effective Date should be greater than Current Valid From Date ');
										return false;
									}
									$.ajax({
										type : 'GET',
										url : 'DMLCollateralAcctCrossRefDetail.jsp',
										data : {
											"action" : 'change',
											"imode" : 'C',
											"saveCollId" : $('#modCollCdId').val(),
											"saveTripartyAgntId" : $('#modTripartyAgntId').val(),
											"saveValidFromDt" : $('#effectiveDateId').val(),
											"saveHouseId" : $('#modHouseId').val(),
											"saveCollAcctId" : $('#modCollAcctId').val(),
											"saveValidToDt" : $('#modValidToDt').val(),
											"saveCtpyId" : $('#modCtpyId').val(),
											"saveActiveFlag" : $('#modActiveId').val(),
										},
										async : false,
										cache : false,
										success : function(data) {
											var index = data.lastIndexOf("}");
											var str = data.substring(1,(index));
											if(str == 'Data Saved Successfully. ') {
												alert(str);												
												$('#saveBtn').prop('disabled', true);
												$('#cancelBtn').prop('disabled', true);
												$('#createBtn').prop('disabled', false);
												$('#modifyBtn').prop('disabled', false);
												$('.modifyClass.saveClass').prop('disabled', true);
											}else {
												alert(str);
												return false;
											}
											modifyFlag = false;
											createFlag = false;
											$('#collateralTypeTable').remove();
											$.ajaxSetup({cache : false});
											$.ajax({
												type : 'GET',
												url : 'DMLCollateralAcctXRefAux.jsp',
												data : {},
												cache : false,
												success : function(data) {
													successCallBack(data);
												},
											});
										},
									});
									dialog1.dialog('close');
								},
								'Cancel' : function(){
									//do activity for cancel
									dialog1.dialog('close');
								}
							}
							
						});
						dialog1.dialog('open');
					}else if(str == 'ACTINACT_OK'){						
						//show dialog div related to active inactive case
						var dialog2 = $('#activeDialog');
						dialog2.dialog({
							modal: true,
						    draggable: false,
						    resizable: false,
						    position: ['center', 'top'],
						    show: 'blind',
						    hide: 'blind',
						    width: 500,
						    height: 250,
							buttons : {
								'Correction' : function() {
									//do activity for correction
									$.ajax({
										type : 'GET',
										url : 'DMLCollateralAcctCrossRefDetail.jsp',
										data : {
											"action" : 'correct',
											"imode" : 'I',
											"saveCollId" : $('#modCollCdId').val(),
											"saveTripartyAgntId" : $('#modTripartyAgntId').val(),
											"saveValidFromDt" : $('#modValidFromDt').val(),
											"saveHouseId" : $('#modHouseId').val(),
											"saveCollAcctId" : $('#modCollAcctId').val(),
											"saveValidToDt" : $('#modValidToDt').val(),
											"saveCtpyId" : $('#modCtpyId').val(),
											"saveActiveFlag" : $('#modActiveId').val(),
										},
										async : false,
										cache : false,
										success : function(data) {
											var index = data.lastIndexOf("}");
											var str = data.substring(1,(index));
											if(str == 'Data Saved Successfully. ') {
												alert(str);												
												$('#saveBtn').prop('disabled', true);
												$('#cancelBtn').prop('disabled', true);
												$('#createBtn').prop('disabled', false);
												$('#modifyBtn').prop('disabled', false);
												$('.modifyClass.saveClass').prop('disabled', true);
											}else {
												alert(str);
												return false;
											}
											modifyFlag = false;
											createFlag = false;
											$('#collateralTypeTable').remove();
											$.ajaxSetup({cache : false});											
											$.ajax({
												type : 'GET',
												url : 'DMLCollateralAcctXRefAux.jsp',
												data : {},
												async : false,
												cache : false,
												success : function(data) {
													successCallBack(data);
												},
											});											
											
										},
									});
									dialog2.dialog('close');
								},
								'Change' : function() {
									//do activity for change
									$.ajax({
										type : 'GET',
										url : 'DMLCollateralAcctCrossRefDetail.jsp',
										data : {
											"action" : 'change',
											"imode" : 'IC',
											"saveCollId" : $('#modCollCdId').val(),
											"saveTripartyAgntId" : $('#modTripartyAgntId').val(),
											"saveValidFromDt" : $('#effectiveDateId').val(),
											"saveHouseId" : $('#modHouseId').val(),
											"saveCollAcctId" : $('#modCollAcctId').val(),
											"saveValidToDt" : $('#modValidToDt').val(),
											"saveCtpyId" : $('#modCtpyId').val(),
											"saveActiveFlag" : $('#modActiveId').val(),
										},
										async : false,
										cache : false,
										success : function(data) {
											var index = data.lastIndexOf("}");
											var str = data.substring(1,(index));
											if(str == 'Data Saved Successfully. ') {
												alert(str);												
												$('#saveBtn').prop('disabled', true);
												$('#cancelBtn').prop('disabled', true);
												$('#createBtn').prop('disabled', false);
												$('#modifyBtn').prop('disabled', false);
												$('.modifyClass.saveClass').prop('disabled', true);
											}else {
												alert(str);
												return false;
											}
											modifyFlag = false;
											createFlag = false;
											$('#collateralTypeTable').remove();
											$.ajaxSetup({cache : false});
											$.ajax({
												type : 'GET',
												url : 'DMLCollateralAcctXRefAux.jsp',
												data : {},
												async : false,
												cache : false,
												success : function(data) {
													successCallBack(data);
												},
											});
										},
									});
									dialog2.dialog('close');
								},
								'Cancel' : function(){
									//do activity for cancel
									dialog2.dialog('close');
								}
							}
							
						});
						dialog2.dialog('open');						
					}else if(str == 'EFFECTIVEDATE_OK') {
						//show dialog div related to effective date case
						var validFr = $('#modValidFromDt').val();
						var today = new Date();
						var validFrDate = new Date(validFr);
						if ( validFr > today ) { //future date
							alert('Valid From Date cannot be greater than today');
							return false;
						}
						if(confirm('You have modified the effective date; do you wish to proceed with this change?')) {
							$.ajax({
								type : 'GET',
								url : 'DMLCollateralAcctCrossRefDetail.jsp',
								data : {
									"action" : 'change',
									"imode" : 'V',
									"saveCollId" : $('#modCollCdId').val(),
									"saveTripartyAgntId" : $('#modTripartyAgntId').val(),
									"saveValidFromDt" : $('#modValidFromDt').val(),
									"saveHouseId" : $('#modHouseId').val(),
									"saveCollAcctId" : $('#modCollAcctId').val(),
									"saveValidToDt" : $('#modValidToDt').val(),
									"saveCtpyId" : $('#modCtpyId').val(),
									"saveActiveFlag" : $('#modActiveId').val(),
								},
								async : false,
								cache : false,
								success : function(data) {
									var index = data.lastIndexOf("}");
									var str = data.substring(1,(index));
									if(str == 'Data Saved Successfully. ') {
										alert(str);										
										$('#saveBtn').prop('disabled', true);
										$('#cancelBtn').prop('disabled', true);
										$('#createBtn').prop('disabled', false);
										$('#modifyBtn').prop('disabled', false);
										$('.modifyClass.saveClass').prop('disabled', true);
									}else {
										alert(str);
										return false;
									}
									modifyFlag = false;
									createFlag = false;
									$('#collateralTypeTable').remove();
									$.ajaxSetup({cache : false});
									$.ajax({
										type : 'GET',
										url : 'DMLCollateralAcctXRefAux.jsp',
										data : {},
										async : false,
										cache : false,
										success : function(data) {
											successCallBack(data);
										},
									});
								},
							});
						}
					}else {
						alert(str);
						return false;
					}
					
				},
			});
		}
	});
	
	$('#refreshBtn').click(function() {
		if(createFlag == true || modifyFlag == true){		
			alert('An attempt has been made to refresh data while in edit mode. Please save or cancel first.');
			return false;
		}		
		var collCdId = $('#collCdId').val();
		var tripartyAgntId = $('#tripartyAgntId').val();
		var validFromDt = $('#validFromDt').val();
		var validToDt = $('#validToDt').val();
		var houseId = $('#houseId').val();
		var collAcctId = $('#collAcctId').val();
		var ctpyId = $('#ctpyId').val();
		var activeId = $('#activeId').val();
		if(validFromDt=="" || validFromDt==null) {
			$('#userNotificationId').html("Please provide value for Valid From Field");
			return false;
		}
		if(validToDt=="" || validToDt==null) {
			$('#userNotificationId').html("Please provide value for Valid To Field");
			return false;
		}
		$.ajaxSetup({cache : false});
		$.ajax({
			type : 'GET',
			url : 'DMLCollateralAcctXRefAux.jsp',
			data : {
				"collCdId" : collCdId,
				"tripartyAgntId" : tripartyAgntId,
				"validFromDt" : validFromDt,
				"validToDt" : validToDt,
				"houseId" : houseId,
				"collAcctId" : collAcctId,
				"ctpyId" : ctpyId,
				"activeId" : activeId,
				action : "search"
			},
			async : false,
			cache : false,
			success : function(data) {
				successCallBack(data);
			},
		});
		
	});
	
	$("body").on('click', 'a#prevId', function() {
		console.log('prevId from on function');
		$('#collateralTypeTable').remove();
		$.ajaxSetup({cache : false});
		$.ajax({
			type : 'GET',
			url : 'DMLCollateralAcctXRefAux.jsp',
			data : {
				action : "prev"
			},
			cache : false,
			success : function(data) {
				successCallBack(data);
			},
		});
		
	});
	
	$("body").on('click', 'a#nextId', function() {
		console.log('nextId from on function');
		$('#collateralTypeTable').remove();
		$.ajaxSetup({cache : false});
		$.ajax({
			type : 'GET',
			url : 'DMLCollateralAcctXRefAux.jsp',
			data : {
				action : "next"
			},
			cache : false,
			success : function(data) {
				successCallBack(data);
			},
		});
	});
	
	
	$('#modTripartyAgntId').change(function() {
		var tpafId = $('#modTripartyAgntId').val();
		$.ajax({
			type : 'GET',
			url : 'ModifyCollAccountDetails.jsp',
			data : {				
				"tpafId" : tpafId,
				"action" : 'ModifyDMLCollAccount' 
			},
			cache : false,
			success : function(data) {
				populateModifyCollAccountData(data);
			},
		});
		
	});
	
	
}); 

var enrichModifyGrid = function(data) {
	console.log('enrichModifyGrid');
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	console.log(data1);
	$('#modHouseId').val(data1.dmlCollAcctXrefDet.modHouseId);
	$('#modCollCdId').val(data1.dmlCollAcctXrefDet.modCollCdId);
	$('#modTripartyAgntId').val(data1.dmlCollAcctXrefDet.modTripartyAgntId);
	$('#modValidFromDt').val(data1.dmlCollAcctXrefDet.modValidFromDt);
	//$('#modCollAcctId').val(data1.dmlCollAcctXrefDet.modCollAcctId);
	$('#modCollAcctId').find('option').each(function() {
		if($(this).val()==data1.dmlCollAcctXrefDet.modCollAcctId)
			$(this).prop("selected", true);
	});
	$('#modValidToDt').val(data1.dmlCollAcctXrefDet.modValidToDt);
	$('#modCtpyId').val(data1.dmlCollAcctXrefDet.modCtpyId);
	$('#modActiveId').val(data1.dmlCollAcctXrefDet.modActiveId);
	$('#modLastModSignOnId').text(data1.dmlCollAcctXrefDet.modLastModSignOnId);
	$('#modLastModDateTime').text(data1.dmlCollAcctXrefDet.modLastModDateTime);
	$('#saveBtn').prop('disabled', false);
	$('#cancelBtn').prop('disabled', false);
}

var enrichModifyGridWithoutSaveAndCancelEnabled = function(data) {
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	console.log(data1);	
	$('#modHouseId').find('option').each(function() {
		if($(this).val()==data1.dmlCollAcctXrefDet.modHouseId)
			$(this).prop("selected", true);
	});
	$('#modCollCdId').val(data1.dmlCollAcctXrefDet.modCollCdId);
	$('#modTripartyAgntId').val(data1.dmlCollAcctXrefDet.modTripartyAgntId);
	$('#modValidFromDt').val(data1.dmlCollAcctXrefDet.modValidFromDt);
	$('#modCollAcctId').val(data1.dmlCollAcctXrefDet.modCollAcctId);
	$('#modValidToDt').val(data1.dmlCollAcctXrefDet.modValidToDt);
	$('#modCtpyId').find('option').each(function() {
		if($(this).val()==data1.dmlCollAcctXrefDet.modCtpyId)
			$(this).prop("selected", true);
	});
	$('#modActiveId').val(data1.dmlCollAcctXrefDet.modActiveId);
	$('#modLastModSignOnId').text(data1.dmlCollAcctXrefDet.modLastModSignOnId);
	$('#modLastModDateTime').text(data1.dmlCollAcctXrefDet.modLastModDateTime);
	$('#curRecFlg').text(data1.dmlCollAcctXrefDet.curRecFlg);
}

var successCallBack = function(data) {
	$('#collateralTypeTable').remove();
	var modHouseId,modActiveId,modCollCdId,modCollAcctId,modTripartyAgntId,modCtpyId;
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	var table = $("<table />");
	table[0].border = "1";
	//table[0].width = "80%";
	table[0].id = "collateralTypeTable";
	var colCount = ["COLLATERALCODE", "HOUSEACCTID", "CTPYID", "TRIPARTYAGNTID", "COLLATERALACCT", "VALIDFROMDT", "VALIDTODT", "ACTIVEFLG", "LASTMODSIGNONID", "LASTMODSIGNONDATE"];
	console.log(colCount);
	var row = $(table[0].insertRow(-1));
	for (var i = 0; i < colCount.length; i++) {
		if (i == 0) {
			var headerCell = $("<th />");
			var domEle = "<input type=\"radio\" id=\"checkAll\"></input>";
			var inputTag = $(domEle).click(checkAll);
			headerCell.html(inputTag);
			row.append(headerCell);
		}
		var headerCell = $("<th />");
		headerCell.html(colCount[i].toUpperCase());
		row.append(headerCell);

	}
	for (var i = 0; i < data1.dmlcollateralAcctCrossRefDetails.length; i++) {
		var row = $(table[0].insertRow(-1));
		if(i==0) {
			var data = $("<td />");
			var domEle = "<input type=\"radio\" name=\"dmlCollAcctXRefs\" checked=\"checked\" value="
					+ data1.dmlcollateralAcctCrossRefDetails[i].ROWID
					+ "></input>";
			var inputTag = $(domEle);
			data.html(inputTag);
			row.append(data);
			
		}
		for (var j = 0; j < colCount.length; j++) {
			if(j==0 && i!=0) {
				var data = $("<td />");
				var domEle = "<input type=\"radio\" name=\"dmlCollAcctXRefs\" value="
						+ data1.dmlcollateralAcctCrossRefDetails[i].ROWID
						+ "></input>";
				var inputTag = $(domEle);
				data.html(inputTag);
				row.append(data);
			}
			var data;
			if(i==0) {
				data = $("<td />");
				modHouseId = data1.dmlcollateralAcctCrossRefDetails[0].HOUSEACCTID;
				modActiveId = data1.dmlcollateralAcctCrossRefDetails[0].ACTIVEFLG;
				modCollCdId = data1.dmlcollateralAcctCrossRefDetails[0].ROWID;
				modCollAcctId = data1.dmlcollateralAcctCrossRefDetails[0].COLLATERALACCT;
				modTripartyAgntId = data1.dmlcollateralAcctCrossRefDetails[0].TRIPARTYAGNTID;
				modCtpyId = data1.dmlcollateralAcctCrossRefDetails[0].CTPYID;
				data.html(data1.dmlcollateralAcctCrossRefDetails[i][colCount[j]]);
	       		row.append(data);
			}else {
				data = $("<td />");
				data.html(data1.dmlcollateralAcctCrossRefDetails[i][colCount[j]]);
				row.append(data);
			}
			
		}
	}
	if(data1.count < data1.recPerPage && data1.count<=10) {
		
	}else if((data1.recPerPage<data1.count) && (data1.recPerPage==10)){
		var paginationRow = $(table[0].insertRow(-1));
		var td1 = $("<td/>")
		var td2 = $("<td/>")
		var td3 = $("<td/>")
		var td4 = $("<td/>")
		var td5 = $("<td/>")
		var td6 = $("<td/>")
		var td7 = $("<td/>")
		var td8 = $("<td/>")
		var td9 = $("<td/>")
		var td10 = $("<td/>")
		var nextBtn = "<a href=\"#\" id=\"nextId\"></a>";
		td10.html($(nextBtn).text("Next"));
		var td11 = $("<td/>")
		paginationRow.append(td1);
		paginationRow.append(td2);
		paginationRow.append(td3);
		paginationRow.append(td4);
		paginationRow.append(td5);
		paginationRow.append(td6);
		paginationRow.append(td7);
		paginationRow.append(td8);
		paginationRow.append(td9);
		paginationRow.append(td10);
		paginationRow.append(td11);
	}else if(data1.recPerPage<data1.count) {
		var paginationRow = $(table[0].insertRow(-1));
		var td1 = $("<td/>")
		var td2 = $("<td/>")
		var prevBtn = "<a href=\"#\" id=\"prevId\"></a>";
		td2.html($(prevBtn).text("Previous"));
		var td3 = $("<td/>")
		var td4 = $("<td/>")
		var td5 = $("<td/>")
		var td6 = $("<td/>")
		var td7 = $("<td/>")
		var td8 = $("<td/>")
		var td9 = $("<td/>")
		var td10 = $("<td/>")
		var nextBtn = "<a href=\"#\" id=\"nextId\"></a>";
		td10.html($(nextBtn).text("Next"));
		var td11 = $("<td/>")
		paginationRow.append(td1);
		paginationRow.append(td2);
		paginationRow.append(td3);
		paginationRow.append(td4);
		paginationRow.append(td5);
		paginationRow.append(td6);
		paginationRow.append(td7);
		paginationRow.append(td8);
		paginationRow.append(td9);
		paginationRow.append(td10);
		paginationRow.append(td11);
	}else if((data1.count-data1.recPerPage)<10) {
		var paginationRow = $(table[0].insertRow(-1));
		var td1 = $("<td/>")
		var td2 = $("<td/>")
		var prevBtn = "<a href=\"#\" id=\"prevId\"></a>";
		td2.html($(prevBtn).text("Previous"));
		var td3 = $("<td/>")
		var td4 = $("<td/>")
		var td5 = $("<td/>")
		var td6 = $("<td/>")
		var td7 = $("<td/>")
		var td8 = $("<td/>")
		var td9 = $("<td/>")
		var td10 = $("<td/>")
		var td11 = $("<td/>")
		paginationRow.append(td1);
		paginationRow.append(td2);
		paginationRow.append(td3);
		paginationRow.append(td4);
		paginationRow.append(td5);
		paginationRow.append(td6);
		paginationRow.append(td7);
		paginationRow.append(td8);
		paginationRow.append(td9);
		paginationRow.append(td10);
		paginationRow.append(td11);
	}
	$.ajaxSetup({cache : false});
	$.ajax({
		type : 'GET',
		url : 'DMLCollateralAcctCrossRefDetail.jsp',
		data : {
			"modHouseId" : modHouseId,
			"modActiveId" : modActiveId,
			"modCollCdId" : modCollCdId,
			"modCollAcctId" : modCollAcctId,
			"modTripartyAgntId" : modTripartyAgntId,
			"modCtpyId" : modCtpyId,
			"action" : 'getDMLCollateralAcctXRefDetails' 
		},
		cache : false,
		success : function(data) {
			enrichModifyGridWithoutSaveAndCancelEnabled(data);
		},
	});
	
	var divId = $('#listId');
	divId.attr("align", "center");
	divId.html();
	divId.append(table);
	var displayCount = $('#displayCount');
	if(data1.count>data1.recPerPage) {
		displayCount.html(data1.recPerPage+" of "+data1.count+" rows");
	}else {
		data1.recPerPage = data1.count;
		displayCount.html(data1.recPerPage+" of "+data1.count+" rows");
	}
	
	
} 

var populateModifyCollAccountData = function(data) {
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	console.log(data1);
	var modCollAccountCd = $('#modCollAcctId');
	modCollAccountCd.find('option').remove();
	$('<option></option>').val("").text("     ").appendTo(modCollAccountCd);
	for(var i=0;i<data1.collateralAccount.length;i++) {
		var collatAcctRes= data1.collateralAccount[i].CODEVALUE +" - "+ data1.collateralAccount[i].CODELONGDESCRIPTION;
		var option = $('<option></option>').val(data1.collateralAccount[i].CODEVALUE).text(collatAcctRes);
		$('#modCollAcctId').append(option);
    } 
}

var populateDMLCtpyIdData = function(data) {
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	console.log(data1);
	var modCtpyId = $('#modCtpyId'); 
	for(var i=0;i<data1.dmlCtpyIds.length;i++) {
		var dmlCtpyId= data1.dmlCtpyIds[i].CODEVALUE +" - "+ data1.dmlCtpyIds[i].CODELONGDESCRIPTION;
		var option = $('<option></option>').val(data1.dmlCtpyIds[i].CODEVALUE).text(dmlCtpyId);
		$('#modCtpyId').append(option);
    } 
}

var populateCollCdData = function(data) {
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	console.log(data1);
	var collCd = $('#collCdId');
	var modCollCd = $('#modCollCdId');
	for(var i=0;i<data1.collateralCodes.length;i++) {
		var option = $('<option></option>').val(data1.collateralCodes[i].CODEVALUE).text(data1.collateralCodes[i].CODELONGDESCRIPTION);
		$('#collCdId').append(option);
    }
	for(var i=0;i<data1.collateralCodes.length;i++) {
		var option = $('<option></option>').val(data1.collateralCodes[i].CODEVALUE).text(data1.collateralCodes[i].CODELONGDESCRIPTION);
		$('#modCollCdId').append(option);
    }
}

var populateTPAFData = function(data) {
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	console.log(data1);
	var tpaf = $('#tripartyAgntId');
	var modTpaf = $('#modTripartyAgntId');
	for(var i=0;i<data1.triPartyAgntFiles.length;i++) {
		var option = $('<option></option>').val(data1.triPartyAgntFiles[i].CODEVALUE).text(data1.triPartyAgntFiles[i].CODELONGDESCRIPTION);
		$('#tripartyAgntId').append(option);
    }
	for(var i=0;i<data1.triPartyAgntFiles.length;i++) {
		var option = $('<option></option>').val(data1.triPartyAgntFiles[i].CODEVALUE).text(data1.triPartyAgntFiles[i].CODELONGDESCRIPTION);
		$('#modTripartyAgntId').append(option);
    }
}

var populateHouseIdData = function(data) {
	var index = data.lastIndexOf("}");
	var str = data.substring(0,(index+1));
	var data1 = JSON.parse(str);
	console.log(data1);
	var houseId = $('#houseId');
	var modHouseId = $('#modHouseId');
	for(var i=0;i<data1.houseId.length;i++) {
		var option = $('<option></option>').val(data1.houseId[i].CODEVALUE).text(data1.houseId[i].CODEVALUE);
		$('#houseId').append(option);
    }
	for(var i=0;i<data1.houseId.length;i++) {
		var option = $('<option></option>').val(data1.houseId[i].CODEVALUE).text(data1.houseId[i].CODEVALUE);
		$('#modHouseId').append(option);
    }
}

function checkAll() {
	if ($('#checkAll').attr("checked")) {
		$('input[type="checkbox"][name="dmlCollAcctXRefs"]').each(function() {
			$(this).attr("checked", true);
		});
	} else {
		$('input[type="checkbox"][name="dmlCollAcctXRefs"]').each(function() {
			$(this).attr("checked", false);
		});
	}
}