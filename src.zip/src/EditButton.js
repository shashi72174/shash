import React, { Component } from 'react';
import $ from 'jquery';

class EditButton extends Component {
    edit(id) {
        alert('edit button clicked =====> '+id);
    }
    render() {
        return (<button onClick={this.edit.bind(this,this.props.id)}>EDIT</button>);
    }

}

export default EditButton;
