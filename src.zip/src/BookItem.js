import React, { Component } from 'react';
import EditButton from './EditButton';


class BookItem extends Component {
    /*edit(id) {
        alert('edit button clicked =====> '+id);
    }*/
    render() {
        return (<tr>
                <td>{this.props.book.ISBN}</td>
                <td>{this.props.book.BOOKNAME}</td>
                <td>{this.props.book.BOOKPRICE}</td>
                <td><EditButton id={this.props.book.BOOKID} /></td>
              </tr>);
    }

}

export default BookItem;
